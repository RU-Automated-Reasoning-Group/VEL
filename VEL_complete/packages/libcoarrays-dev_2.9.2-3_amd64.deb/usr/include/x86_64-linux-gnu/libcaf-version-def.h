#if __GNUC__ >= 8
#define GCC_GE_8 1
#endif

#if __GNUC__ >= 7
#define GCC_GE_7 1
#endif
